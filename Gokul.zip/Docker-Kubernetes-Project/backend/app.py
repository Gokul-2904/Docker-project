from flask import Flask, request, jsonify
from flask_cors import CORS  # Add this import
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app, resources={r"/docker": {"origins": "http://localhost:8080"}})
def get_db_connection():
    return psycopg2.connect(
        host=os.getenv('DB_HOST'),
        database=os.getenv('DB_NAME'),
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASSWORD'),
        port=os.getenv('DB_PORT')
    )

@app.route('/submit', methods=['POST'])
def register():
    data = request.get_json()
    name = data.get('name')
    number = data.get('phone_no')
    gender = data.get('gender')
    languages = data.get('languages')  # This will be a list

    conn = get_db_connection()
    cur = conn.cursor()

    try:
        cur.execute("""
            INSERT INTO users (name, phone_no, gender, languages)
            VALUES (%s, %s, %s, %s)
        """, (name, phone_no, gender, ','.join(languages)))

        conn.commit()
        return jsonify({'message': 'Successful'}), 200

    except Exception as e:
        print(e)
        return jsonify({'message': 'Error: ' + str(e)}), 500
    finally:
        cur.close()
        conn.close()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
