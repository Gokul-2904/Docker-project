document.getElementById('dockerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('name').value;
    const phone_no = document.getElementById('phone').value;
    const gender = document.getElementById('gender').value;
    const languages = document.getElementById('languages').value;
    try {
        const response = await fetch('http://localhost:5000/docker', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ name, phone_no,gender,languages }),
        });

        const data = await response.json();
        document.getElementById('message').textContent = data.message;
        document.getElementById('message').style.color = response.ok ? 'green' : 'red';
    } catch (error) {
        document.getElementById('message').textContent = 'Error connecting to server';
        document.getElementById('message').style.color = 'red';
    }
});